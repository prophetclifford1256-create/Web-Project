import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Product {
  _id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  isVideo?: boolean;
  isNew?: boolean;
  isBestSeller?: boolean;
  stock: number;
}

interface CartItem extends Product {
  quantity: number;
}

export type OrderStatus = 'Pending' | 'Processing' | 'Shipped' | 'Out for Delivery' | 'Delivered';

export interface Order {
  id: string;
  customer: string;
  email?: string;
  date: string;
  status: OrderStatus;
  total: number;
  items?: any[];
}

interface StoreState {
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  user: any | null;
  setUser: (user: any) => void;
  orders: Order[];
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  addOrder: (order: Order) => void;
  adminProfilePic: string | null;
  setAdminProfilePic: (url: string) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      adminProfilePic: 'https://i.pinimg.com/736x/db/f8/2b/dbf82b4ce63f2a8bb38d4d1022586605.jpg',
      setAdminProfilePic: (url) => set({ adminProfilePic: url }),
      cart: [],
      addToCart: (product, quantity = 1) =>
        set((state) => {
          const existing = state.cart.find((item) => item._id === product._id);
          if (existing) {
            return {
              cart: state.cart.map((item) =>
                item._id === product._id
                  ? { ...item, quantity: item.quantity + quantity }
                  : item
              ),
            };
          }
          return { cart: [...state.cart, { ...product, quantity }] };
        }),
      removeFromCart: (productId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item._id !== productId),
        })),
      updateQuantity: (productId, quantity) =>
        set((state) => ({
          cart: state.cart.map((item) =>
            item._id === productId ? { ...item, quantity } : item
          ),
        })),
      clearCart: () => set({ cart: [] }),
      user: null,
      setUser: (user) => set({ user }),
      orders: [],
      updateOrderStatus: (orderId, status) =>
        set((state) => ({
          orders: state.orders.map((o) => (o.id === orderId ? { ...o, status } : o)),
        })),
      addOrder: (order) => set((state) => ({ orders: [order, ...state.orders] })),
    }),
    {
      name: 'jaybeauty-store',
    }
  )
);
