export default function Footer() {
  return (
    <footer className="bg-primary-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div>
            <div className="text-2xl font-bold font-sans tracking-tight mb-4">JAY BEAUTY</div>
            <p className="text-gray-400 text-sm leading-relaxed">
              Premium fashion and beauty collections based in Ghana. We deliver across Accra and Winneba. Elevating your style organically.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Shop</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="/shop?category=Women" className="hover:text-accent-orange transition-colors">Women's Collection</a></li>
              <li><a href="/shop?category=Men" className="hover:text-accent-orange transition-colors">Men's Collection</a></li>
              <li><a href="/shop?isNew=true" className="hover:text-accent-orange transition-colors">New Arrivals</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Support</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><a href="/track" className="hover:text-accent-orange transition-colors">Track Order</a></li>
              <li><a href="#" className="hover:text-accent-orange transition-colors">Shipping & Returns</a></li>
              <li><a href="#" className="hover:text-accent-orange transition-colors">Size Guide</a></li>
              <li><a href="tel:0548630196" target="_blank" rel="noopener noreferrer" className="hover:text-accent-orange transition-colors">Contact Us</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-gray-200">Join our newsletter</h4>
            <div className="flex">
              <input type="email" placeholder="Email address" className="bg-primary-800 text-white px-4 py-2 w-full focus:outline-none focus:ring-1 focus:ring-accent-orange text-sm rounded-l-sm" />
              <button className="bg-accent-orange hover:bg-orange-600 text-white px-4 py-2 text-sm font-medium transition-colors rounded-r-sm">
                Subscribe
              </button>
            </div>
            <p className="mt-4 text-xs text-gray-400">Admin WhatsApp: <a href="https://wa.me/233548630196" target="_blank" rel="noopener noreferrer" className="text-white">0548630196</a></p>
          </div>
        </div>
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">© {new Date().getFullYear()} Jay Beauty Collections. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0 text-sm">
            <span className="text-gray-500">GHS (₵)</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
