import React from 'react';

export default function MediaDisplay({ src, alt, className, isVideo, ...props }: { src: string, alt: string, className?: string, isVideo?: boolean } & React.ImgHTMLAttributes<HTMLImageElement> & React.VideoHTMLAttributes<HTMLVideoElement>) {
  if (isVideo || src.match(/\.(mp4|webm|ogg)$/i)) {
    return (
      <video
        src={src}
        className={className}
        autoPlay
        loop
        muted
        playsInline
        {...props as React.VideoHTMLAttributes<HTMLVideoElement>}
      />
    );
  }
  return <img 
    src={src} 
    alt={alt} 
    className={className} 
    loading="lazy"
    referrerPolicy="no-referrer"
    {...props as React.ImgHTMLAttributes<HTMLImageElement>} 
  />;
}
