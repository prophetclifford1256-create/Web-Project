import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router';
import { Filter, ChevronDown, ArrowRight, MessageCircle, Search } from 'lucide-react';
import { Product, useStore } from '../store/useStore';
import MediaDisplay from '../components/MediaDisplay';
import { db } from '../lib/firebase';
import { collection, onSnapshot, query } from 'firebase/firestore';

export default function Shop() {
  const [searchParams] = useSearchParams();
  const categoryFilter = searchParams.get('category');
  const searchQuery = searchParams.get('search')?.toLowerCase() || '';
  
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  const addToCart = useStore(state => state.addToCart);

  useEffect(() => {
    const q = query(collection(db, "products"));
    const unsub = onSnapshot(q, (snap) => {
      const fbProducts = snap.docs.map(d => ({ 
        _id: d.id, 
        ...d.data() 
      } as Product));
      
      setProducts(fbProducts);
      
      let items = fbProducts;
      
      if (categoryFilter) {
        items = items.filter(p => p.category === categoryFilter);
      }
      
      if (searchQuery) {
        items = items.filter(p => 
          p.name.toLowerCase().includes(searchQuery) || 
          p.category.toLowerCase().includes(searchQuery)
        );
      }
      
      setFilteredProducts(items);
      setLoading(false);
    });
    
    return unsub;
  }, [categoryFilter, searchQuery]);

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center">Loading...</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <div className="sticky top-24">
            <h2 className="text-xl font-bold flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Filter className="h-5 w-5" /> Filters
            </h2>
            
            <div className="mb-8">
              <h3 className="font-semibold mb-4">Categories</h3>
              <ul className="space-y-3 text-sm text-gray-600">
                <li><Link to="/shop" className={`hover:text-accent-orange ${!categoryFilter ? 'text-accent-orange font-medium' : ''}`}>All Categories</Link></li>
                <li><Link to="/shop?category=Women" className={`hover:text-accent-orange ${categoryFilter === 'Women' ? 'text-accent-orange font-medium' : ''}`}>Women</Link></li>
                <li><Link to="/shop?category=Men" className={`hover:text-accent-orange ${categoryFilter === 'Men' ? 'text-accent-orange font-medium' : ''}`}>Men</Link></li>
                <li><Link to="/shop?category=Dresses" className={`hover:text-accent-orange ${categoryFilter === 'Dresses' ? 'text-accent-orange font-medium' : ''}`}>Dresses</Link></li>
                <li><Link to="/shop?category=Tops" className={`hover:text-accent-orange ${categoryFilter === 'Tops' ? 'text-accent-orange font-medium' : ''}`}>Tops</Link></li>
                <li><Link to="/shop?category=Bottoms" className={`hover:text-accent-orange ${categoryFilter === 'Bottoms' ? 'text-accent-orange font-medium' : ''}`}>Bottoms</Link></li>
              </ul>
            </div>

            <div className="mb-8">
              <h3 className="font-semibold mb-4">Price</h3>
              <input type="range" min="0" max="1000" className="w-full accent-accent-orange" />
              <div className="flex justify-between text-xs text-gray-500 mt-2">
                <span>GH₵ 0</span>
                <span>GH₵ 1000+</span>
              </div>
            </div>
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-8">
            <p className="text-gray-500 text-sm">Showing {filteredProducts.length} results</p>
            <button className="flex items-center gap-2 text-sm border border-gray-200 px-4 py-2 rounded-full hover:bg-gray-50">
              Sort by: Recommended <ChevronDown className="h-4 w-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.length > 0 ? (
              filteredProducts.map((product) => (
                <div key={product._id} className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300">
                  <Link to={`/product/${product._id}`} className="block relative aspect-[3/4] overflow-hidden bg-gray-100">
                    <MediaDisplay src={product.image} alt={product.name} isVideo={product.isVideo} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </Link>
                  <div className="p-6">
                    <p className="text-xs text-gray-500 uppercase tracking-wider mb-2">{product.category}</p>
                    <Link to={`/product/${product._id}`} className="block">
                      <h3 className="text-lg font-bold text-primary-900 mb-2 truncate">{product.name}</h3>
                    </Link>
                    <div className="flex justify-between items-center mt-4">
                      <span className="font-semibold text-lg text-primary-900">GH₵ {product.price.toFixed(2)}</span>
                      <div className="flex gap-2">
                        <button 
                          onClick={(e) => { 
                            e.preventDefault();
                            const randomOrderId = 'JBC-' + Math.random().toString(10).substring(2, 6).toUpperCase();
                            const message = encodeURIComponent(`Hi, I would like to order: ${product.name} (GH₵${product.price.toFixed(2)})\nOrder ID: ${randomOrderId}`);
                            window.open(`https://wa.me/233548630196?text=${message}`, '_blank');
                          }}
                          className="bg-[#25D366] hover:bg-[#128C7E] text-white p-0 h-10 w-10 flex items-center justify-center rounded-full transition-colors shadow-sm overflow-hidden"
                          title="Order via WhatsApp"
                        >
                          <img src="https://i1-e.pinimg.com/1200x/2f/e7/7c/2fe77c40e6ab4b44b8fe4f9e0334f403.jpg" alt="WhatsApp" className="h-full w-full object-cover scale-150" />
                        </button>
                        <button 
                          onClick={(e) => { e.preventDefault(); addToCart(product); }}
                          className="bg-gray-100 hover:bg-accent-orange hover:text-white p-3 rounded-full transition-colors shadow-sm"
                          title="Add to Cart"
                        >
                          <ArrowRight className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full py-20 text-center">
                <Search className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">No products found</h3>
                <p className="text-gray-500">Try adjusting your filters or search terms.</p>
                <Link to="/shop" className="inline-block mt-4 text-accent-orange font-bold">Clear all filters</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
