import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router';
import { LayoutDashboard, ShoppingBag, Users, Settings, PackageOpen, AlertTriangle, Trash2, Menu, X } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { db } from '../lib/firebase';
import { collection, onSnapshot, doc, updateDoc, orderBy, query, deleteDoc, setDoc } from 'firebase/firestore';

const data = [
  { name: 'Mon', sales: 4000 },
  { name: 'Tue', sales: 3000 },
  { name: 'Wed', sales: 5000 },
  { name: 'Thu', sales: 2780 },
  { name: 'Fri', sales: 8890 },
  { name: 'Sat', sales: 12390 },
  { name: 'Sun', sales: 9490 },
];

import { useStore, OrderStatus, Order } from '../store/useStore';
import MediaDisplay from '../components/MediaDisplay';

function useFirebaseOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  useEffect(() => {
    const q = query(collection(db, "orders")); // no timestamp index so just query
    const unsub = onSnapshot(q, (snap) => {
      const fbOrders = snap.docs.map(d => ({ ...d.data() } as Order));
      // order by date descending purely client-side to avoid needing an index
      fbOrders.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setOrders(fbOrders);
    });
    return unsub;
  }, []);
  return orders;
}

function DashboardHome() {
  const orders = useFirebaseOrders();
  const totalSales = orders.reduce((acc, o) => acc + o.total, 0);
  const activeCustomers = new Set(orders.map(o => o.email).filter(Boolean)).size;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
          <p className="text-xs text-slate-500 mb-1">Total Sales</p>
          <h3 className="text-2xl font-bold text-slate-800">GH₵ {totalSales.toLocaleString(undefined, { minimumFractionDigits: 2 })}</h3>
          <p className="text-[10px] text-green-500 mt-2">+0% from last week</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
          <p className="text-xs text-slate-500 mb-1">Total Orders</p>
          <h3 className="text-2xl font-bold text-slate-800">{orders.length}</h3>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm">
          <p className="text-xs text-slate-500 mb-1">Active Customers</p>
          <h3 className="text-2xl font-bold text-slate-800">{activeCustomers}</h3>
        </div>
        <div className="bg-white p-4 rounded-xl border border-red-100 shadow-sm bg-red-50">
          <p className="text-[10px] text-red-500 font-medium flex items-center gap-1 mb-1"><AlertTriangle className="h-3 w-3" /> Low Stock Alerts</p>
          <h3 className="text-2xl font-bold text-red-700">3 Items</h3>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
        <h3 className="font-bold mb-6">Sales Overview</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} />
              <YAxis axisLine={false} tickLine={false} tickFormatter={(value) => `₵${value}`} />
              <Tooltip />
              <Line type="monotone" dataKey="sales" stroke="#f97316" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function Orders() {
  const orders = useFirebaseOrders();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const handleStatusChange = async (orderId: string, status: OrderStatus, email: string | undefined, customerName: string) => {
    try {
      await updateDoc(doc(db, "orders", orderId), { status });
    } catch (err) {
      console.error("Failed to update status on Firebase", err);
    }
    
    if (email) {
      try {
        await fetch('/api/orders/notify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            orderId,
            type: 'status_update',
            email,
            customerName,
            status
          })
        });
      } catch (error) {
        console.error('Failed to send status notification', error);
      }
    }
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (!window.confirm(`Are you sure you want to delete order #${orderId}?`)) return;
    try {
      await deleteDoc(doc(db, "orders", orderId));
    } catch (err) {
      console.error("Failed to delete order from Firebase", err);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden flex-1">
      <div className="p-4 border-b flex justify-between items-center">
        <h3 className="font-bold text-sm">Recent Orders</h3>
        <button className="text-[10px] text-accent-orange font-bold uppercase tracking-wider">Download CSV</button>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-white text-slate-400 text-[11px] uppercase tracking-wider divide-y">
            <tr className="border-b border-gray-100">
              <th className="px-4 py-4 font-medium">Order ID</th>
              <th className="px-4 py-4 font-medium">Customer</th>
              <th className="px-4 py-4 font-medium">Date</th>
              <th className="px-4 py-4 font-medium">Total</th>
              <th className="px-4 py-4 font-medium">Status</th>
              <th className="px-4 py-4 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {orders.map((o) => (
              <tr key={o.id} className="hover:bg-gray-50">
                <td className="px-4 py-4 font-mono font-medium text-xs text-slate-400">#{o.id}</td>
                <td className="px-4 py-4 font-semibold text-sm">{o.customer}</td>
                <td className="px-4 py-4 text-xs text-slate-400">{o.date}</td>
                <td className="px-4 py-4 font-bold text-sm text-slate-800">GH₵ {o.total.toFixed(2)}</td>
                <td className="px-4 py-4">
                  <select
                    className={`px-2 py-1 rounded-full text-[10px] font-medium border-0 focus:ring-2 focus:ring-accent-orange outline-none
                    ${o.status === 'Delivered' ? 'bg-green-100 text-green-700' : 
                      o.status === 'Processing' ? 'bg-yellow-100 text-yellow-700' : 
                      o.status === 'Shipped' || o.status === 'Out for Delivery' ? 'bg-blue-100 text-blue-700' :
                      'bg-slate-100 text-slate-700'}`}
                    value={o.status}
                    onChange={(e) => handleStatusChange(o.id, e.target.value as OrderStatus, o.email, o.customer)}
                  >
                    {['Pending', 'Processing', 'Shipped', 'Out for Delivery', 'Delivered'].map(status => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-4 text-right flex justify-end gap-3">
                  <button 
                    onClick={() => setSelectedOrder(o)}
                    className="text-[10px] text-accent-orange hover:underline font-bold uppercase tracking-wider"
                  >
                    View
                  </button>
                  <button 
                    onClick={() => handleDeleteOrder(o.id)}
                    className="text-red-500 hover:text-red-700 transition-colors"
                    title="Delete Order"
                  >
                    <Trash2 size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[110] p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6">
            <div className="flex justify-between items-start mb-6">
              <div>
                <h2 className="text-xl font-bold">Order Details</h2>
                <p className="text-sm text-slate-500">Order #{selectedOrder.id}</p>
              </div>
              <button 
                onClick={() => setSelectedOrder(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>
            
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] uppercase text-slate-400 font-bold mb-1">Customer</p>
                  <p className="font-medium">{selectedOrder.customer}</p>
                  <p className="text-xs text-slate-500">{selectedOrder.email}</p>
                </div>
                <div>
                  <p className="text-[10px] uppercase text-slate-400 font-bold mb-1">Date</p>
                  <p className="font-medium">{selectedOrder.date}</p>
                </div>
              </div>

              <div>
                <p className="text-[10px] uppercase text-slate-400 font-bold mb-3">Items</p>
                <div className="space-y-3">
                  {selectedOrder.items?.map((item, idx) => (
                    <div key={idx} className="flex gap-3 items-center">
                      <div className="w-10 h-10 bg-slate-100 rounded overflow-hidden flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{item.name}</p>
                        <p className="text-xs text-slate-500">{item.quantity} x GH₵ {item.price.toFixed(2)}</p>
                      </div>
                      <p className="text-sm font-bold">GH₵ {(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-slate-500">Subtotal</span>
                  <span>GH₵ {selectedOrder.total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total</span>
                  <span className="text-accent-orange">GH₵ {selectedOrder.total.toFixed(2)}</span>
                </div>
              </div>
              
              <div className="flex gap-3 pt-4">
                 <button 
                   onClick={() => setSelectedOrder(null)}
                   className="flex-1 bg-slate-100 text-slate-600 py-3 rounded-xl font-bold text-sm hover:bg-slate-200"
                 >
                   Close
                 </button>
                 {selectedOrder.status !== 'Delivered' && (
                   <button 
                     onClick={() => {
                        handleStatusChange(selectedOrder.id, 'Delivered', selectedOrder.email, selectedOrder.customer);
                        setSelectedOrder(prev => prev ? {...prev, status: 'Delivered'} : null);
                     }}
                     className="flex-1 bg-green-600 text-white py-3 rounded-xl font-bold text-sm hover:bg-green-700"
                   >
                     Mark as Delivered
                   </button>
                 )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Products() {
  const [products, setProducts] = useState<any[]>([]);
  const [editedPrices, setEditedPrices] = useState<Record<string, number>>({});
  const [editedStock, setEditedStock] = useState<Record<string, number>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState('');
  
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    image: '',
    isVideo: false,
    isNew: false,
    isBestSeller: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch products from Firestore
  useEffect(() => {
    const q = query(collection(db, "products"));
    const unsub = onSnapshot(q, (snap) => {
      const fbProducts = snap.docs.map(d => ({ 
        _id: d.id, 
        ...d.data() 
      }));
      setProducts(fbProducts);
    });
    return unsub;
  }, []);

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    try {
      await deleteDoc(doc(db, "products", id));
      setMessage('Product deleted successfully!');
    } catch (err) {
      console.error(err);
      setMessage('Error deleting product.');
    } finally {
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handlePriceChange = (id: string, newPrice: string) => {
    setEditedPrices(prev => ({
      ...prev,
      [id]: parseFloat(newPrice) || 0
    }));
  };

  const handleStockChange = (id: string, newStock: string) => {
    setEditedStock(prev => ({
      ...prev,
      [id]: parseInt(newStock) || 0
    }));
  };

  const handleBulkSave = async () => {
    const ids = new Set([...Object.keys(editedPrices), ...Object.keys(editedStock)]);
    
    if (ids.size === 0) {
      setMessage('No changes to save.');
      setTimeout(() => setMessage(''), 3000);
      return;
    }

    setIsSaving(true);
    setMessage('');
    try {
      // Use Firestore batch write or individual updates
      for (const id of ids) {
        const update: any = {};
        if (editedPrices[id] !== undefined) update.price = editedPrices[id];
        if (editedStock[id] !== undefined) update.stock = editedStock[id];
        
        await updateDoc(doc(db, "products", id), update);
      }
      
      setEditedPrices({});
      setEditedStock({});
      setMessage('Products updated successfully!');
    } catch (err) {
      console.error(err);
      setMessage('An error occurred while saving.');
    } finally {
      setIsSaving(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const productToSave = {
        ...newProduct,
        price: parseFloat(newProduct.price as string) || 0,
        stock: parseInt(newProduct.stock as string) || 0,
        createdAt: new Date().toISOString()
      };
      
      const newDocRef = doc(collection(db, "products"));
      await setDoc(newDocRef, productToSave);
      
      setIsAddingProduct(false);
      setNewProduct({ name: '', category: '', price: '', stock: '', image: '', isVideo: false, isNew: false, isBestSeller: false });
      setMessage('Product added successfully!');
    } catch (err) {
      console.error(err);
      setMessage('Error adding product.');
    } finally {
      setIsSubmitting(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 relative">
       <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-lg">Manage Products</h3>
        <div className="flex items-center gap-4">
          {message && <span className="text-sm font-medium text-green-600">{message}</span>}
          <button 
            onClick={handleBulkSave}
            disabled={isSaving || (Object.keys(editedPrices).length === 0 && Object.keys(editedStock).length === 0)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              (Object.keys(editedPrices).length > 0 || Object.keys(editedStock).length > 0)
                ? 'bg-accent-orange text-white hover:bg-orange-600' 
                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
            }`}
          >
            {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
          <button 
            onClick={() => setIsAddingProduct(true)}
            className="bg-primary-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary-800 transition-colors"
          >
            Add Product
          </button>
        </div>
      </div>
      
      {isAddingProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl w-full max-w-md">
            <h3 className="text-lg font-bold mb-4">Add New Product</h3>
            <form onSubmit={handleAddProduct} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input required type="text" value={newProduct.name} onChange={e => setNewProduct(prev => ({...prev, name: e.target.value}))} className="w-full px-3 py-2 border rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Image/Video URL</label>
                <div className="flex gap-2">
                  <input type="text" value={newProduct.image} onChange={e => setNewProduct(prev => ({...prev, image: e.target.value}))} className="w-full px-3 py-2 border rounded-lg" />
                  <label className="flex items-center gap-2 text-sm text-gray-700 whitespace-nowrap bg-gray-50 px-3 border border-gray-200 rounded-lg">
                    <input type="checkbox" checked={newProduct.isVideo} onChange={e => setNewProduct(prev => ({...prev, isVideo: e.target.checked}))} />
                    Is Video
                  </label>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Price (GH₵)</label>
                  <input required type="number" step="0.01" value={newProduct.price} onChange={e => setNewProduct(prev => ({...prev, price: e.target.value}))} className="w-full px-3 py-2 border rounded-lg" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Stock</label>
                  <input type="number" value={newProduct.stock} onChange={e => setNewProduct(prev => ({...prev, stock: e.target.value}))} className="w-full px-3 py-2 border rounded-lg" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select value={newProduct.category} onChange={e => setNewProduct(prev => ({...prev, category: e.target.value}))} className="w-full px-3 py-2 border rounded-lg">
                  <option value="">Select Category</option>
                  <option value="Dresses">Dresses</option>
                  <option value="Tops">Tops</option>
                  <option value="Bottoms">Bottoms</option>
                  <option value="Men">Men</option>
                </select>
              </div>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input type="checkbox" checked={newProduct.isNew} onChange={e => setNewProduct(prev => ({...prev, isNew: e.target.checked}))} />
                  New Arrival
                </label>
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input type="checkbox" checked={newProduct.isBestSeller} onChange={e => setNewProduct(prev => ({...prev, isBestSeller: e.target.checked}))} />
                  Best Seller
                </label>
              </div>
              <div className="flex justify-end gap-3 mt-6">
                <button type="button" onClick={() => setIsAddingProduct(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Cancel</button>
                <button type="submit" disabled={isSubmitting} className="px-4 py-2 bg-primary-900 text-white rounded-lg hover:bg-primary-800 disabled:opacity-50">
                  {isSubmitting ? 'Adding...' : 'Add Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-white text-slate-400 text-[11px] uppercase tracking-wider divide-y border-b border-gray-100">
            <tr>
              <th className="px-4 py-3 font-medium">Image</th>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Stock</th>
              <th className="px-4 py-3 font-medium">Price (GH₵)</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {products.map((p) => (
              <tr key={p._id} className="hover:bg-slate-50 transition-colors">
                <td className="px-4 py-3">
                  <div className="w-10 h-10 rounded overflow-hidden">
                    <MediaDisplay src={p.image} alt={p.name} isVideo={p.isVideo} className="w-full h-full object-cover" />
                  </div>
                </td>
                <td className="px-4 py-3 font-medium text-slate-800">{p.name}</td>
                <td className="px-4 py-3 text-slate-500">{p.category}</td>
                <td className="px-4 py-3">
                  <input 
                    type="number" 
                    className={`w-20 px-2 py-1 border border-slate-200 rounded focus:outline-none focus:ring-2 focus:ring-accent-orange transition-all ${p.stock < 10 ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}
                    value={editedStock[p._id] !== undefined ? editedStock[p._id] : p.stock}
                    onChange={(e) => handleStockChange(p._id, e.target.value)}
                  />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center">
                    <span className="text-slate-400 mr-2">₵</span>
                    <input 
                      type="number" 
                      min="0"
                      step="0.01"
                      className="w-24 px-2 py-1 border border-slate-200 rounded focus:outline-none focus:ring-2 focus:ring-accent-orange focus:border-transparent transition-all"
                      value={editedPrices[p._id] !== undefined ? editedPrices[p._id] : p.price}
                      onChange={(e) => handlePriceChange(p._id, e.target.value)}
                    />
                  </div>
                </td>
                <td className="px-4 py-3 text-right">
                  <button 
                    onClick={() => handleDeleteProduct(p._id)} 
                    className="text-red-500 hover:text-red-700 font-medium text-xs bg-red-50 hover:bg-red-100 px-3 py-1 rounded-lg transition-colors"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function AdminSettings() {
  const adminProfilePic = useStore((state) => state.adminProfilePic);
  const setAdminProfilePic = useStore((state) => state.setAdminProfilePic);
  const [profileUrl, setProfileUrl] = useState(adminProfilePic || '');
  const [message, setMessage] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminProfilePic(profileUrl);
    setMessage('Settings saved successfully!');
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 max-w-2xl">
      <h3 className="font-bold text-lg mb-6">Admin Settings</h3>
      {message && <div className="mb-4 p-3 bg-green-50 text-green-700 text-sm rounded-lg">{message}</div>}
      <form onSubmit={handleSave} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Profile Picture URL</label>
          <div className="flex gap-4 items-start">
            <div className="w-16 h-16 rounded-full bg-slate-200 overflow-hidden flex-shrink-0 border border-slate-300">
              {profileUrl ? (
                <img src={profileUrl} alt="Preview" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-slate-400">
                  <Users size={24} />
                </div>
              )}
            </div>
            <div className="flex-1">
              <input 
                type="text" 
                value={profileUrl}
                onChange={(e) => setProfileUrl(e.target.value)}
                placeholder="https://example.com/avatar.jpg"
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-accent-orange focus:border-transparent outline-none" 
              />
              <p className="text-xs text-slate-500 mt-1">Provide a valid image URL for your admin profile picture.</p>
            </div>
          </div>
        </div>
        <button type="submit" className="bg-primary-900 text-white px-6 py-2 rounded-lg font-medium hover:bg-primary-800 transition-colors">
          Save Settings
        </button>
      </form>
    </div>
  );
}

export default function Admin() {
  const location = useLocation();
  const currentPath = location.pathname.replace('/admin', '') || '/';
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const adminProfilePic = useStore((state) => state.adminProfilePic);

  const menu = [
    { path: '/', icon: <LayoutDashboard />, label: 'Dashboard' },
    { path: '/orders', icon: <ShoppingBag />, label: 'Orders' },
    { path: '/products', icon: <PackageOpen />, label: 'Products' },
    { path: '/customers', icon: <Users />, label: 'Customers' },
    { path: '/settings', icon: <Settings />, label: 'Settings' },
  ];

  return (
    <div className="flex h-screen bg-gray-50 absolute inset-0 z-[100] overflow-hidden">
      {/* Mobile Sidebar Backdrop */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-[110] md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar - responsive and isolated from public app */}
      <div className={`
        fixed md:relative inset-y-0 left-0 w-64 bg-primary-900 text-white flex flex-col h-full shadow-xl z-[120] transition-transform duration-300 ease-in-out
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="p-6 border-b border-slate-700 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 overflow-hidden rounded-sm flex-shrink-0">
              <img 
                src="https://i.pinimg.com/736x/db/f8/2b/dbf82b4ce63f2a8bb38d4d1022586605.jpg" 
                alt="Logo" 
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-accent-orange leading-tight uppercase">JAY BEAUTY</h1>
              <p className="text-[10px] text-slate-400">Admin Dashboard</p>
            </div>
          </div>
          <button className="md:hidden text-white/60 hover:text-white" onClick={() => setIsSidebarOpen(false)}>
            <X size={20} />
          </button>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {menu.map(item => {
            const isActive = currentPath === item.path;
            return (
              <Link 
                key={item.path} 
                to={`/admin${item.path === '/' ? '' : item.path}`}
                onClick={() => setIsSidebarOpen(false)}
                className={`flex items-center gap-3 px-4 py-2 rounded-lg transition-colors ${isActive ? 'bg-accent-orange text-white font-medium' : 'text-white opacity-60 hover:opacity-100'}`}
              >
                {item.icon}
                <span className="text-sm">{item.label}</span>
              </Link>
            )
          })}
        </nav>
        <div className="p-4 mt-auto bg-primary-800">
          <p className="text-[10px] uppercase text-slate-500 mb-1">Inventory Alert</p>
          <p className="text-xs mb-4">4 Items Low in Stock</p>
          <Link to="/" className="text-gray-400 hover:text-white text-xs block">
             Back to Store -&gt;
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden w-full">
        <header className="h-16 bg-white border-b border-gray-100 flex items-center justify-between px-4 md:px-8">
          <div className="flex items-center gap-4">
            <button 
              className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <h2 className="font-bold text-lg capitalize">{currentPath.replace('/', '') || 'Dashboard'}</h2>
          </div>
          <div className="flex items-center space-x-2 md:space-x-4">
            <span className="hidden sm:inline-block px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded uppercase">Accra Hub Active</span>
            <span className="text-xs md:text-sm font-medium">Admin</span>
            <div className="w-8 h-8 bg-slate-200 rounded-full overflow-hidden border border-slate-300 flex items-center justify-center">
              {adminProfilePic ? (
                <img src={adminProfilePic} alt="Admin Profile" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
              ) : (
                <Users size={16} className="text-slate-400" />
              )}
            </div>
          </div>
        </header>
        <main className="flex-1 overflow-y-auto p-8 relative z-10">
          <Routes>
            <Route path="/" element={<DashboardHome />} />
            <Route path="/orders" element={<Orders />} />
            <Route path="/products" element={<Products />} />
            <Route path="/settings" element={<AdminSettings />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
