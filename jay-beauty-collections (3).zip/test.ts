import { initializeApp } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

const app = initializeApp({projectId: "gen-lang-client-0515097447"});
const db = getFirestore("ai-studio-218b171f-c60a-4351-9612-67ffaf8417e2");
console.log("DB collection exists:", !!db.collection);
